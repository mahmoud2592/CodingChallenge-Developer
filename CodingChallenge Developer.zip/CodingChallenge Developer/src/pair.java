
public class pair<email,phone>{
	
	private email email;
	private phone phone;
	
	public pair(email email,phone phone) {
		this.email = email;
		this.phone = phone;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((phone == null) ? 0 : phone.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		pair other = (pair) obj;
		if (phone == null) {
			if (other.phone != null)
				return false;
		} else if (!phone.equals(other.phone))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		return true;
	}



	public email getemail() {
		return email;
	}

	public void setemail(email email) {
		this.email = email;
	}

	public phone getphone() {
		return phone;
	}

	public void setphone(phone phone) {
		this.phone = phone;
	}
}
