
public class pair<name,email>{
	
	private name name;
	private email email;
	
	public pair(name name,email email) {
		this.name = name;
		this.email = email;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		pair other = (pair) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}



	public name getName() {
		return name;
	}

	public void setName(name name) {
		this.name = name;
	}

	public email getEmail() {
		return email;
	}

	public void setEmail(email email) {
		this.email = email;
	}
}
