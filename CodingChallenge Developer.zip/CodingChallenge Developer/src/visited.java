import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;

import java.util.Scanner;  // Import the Scanner class


public class visited{
	
	private String filePath = "";
	private int count;
	private HashSet<pair<String,String>> users = new HashSet<pair<String,String>>();// hashset top store non-duplicate unique composite values 
	
	public visited(String filePath) {

		this.filePath = filePath;
		
		countVisited(filePath);
	}
	
	public void countVisited(String fileName) { // read from file and count number of visitors
		
		String line = "";
        String csvSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

            while ((line = br.readLine()) != null) {
            	String[] s = new String[3];
                s = line.split(csvSplitBy);// use comma as separator
                pair<String,String> user = new pair<String,String>(s[0], s[1]);// read name and email of the user
                users.add(user); // add this object to the hashset
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public int count(){
		count = users.size();// count number of users
		return count;
	}
	
	public static void main(String[] args) {

	    Scanner scanner = new Scanner(System.in);
	    
	    System.out.println("Please, Enter the file path?");
	    String filePath = scanner.nextLine();  // Read user input file path

		visited myVisited = new visited(filePath);
		System.out.println(myVisited.count());
	}

}
